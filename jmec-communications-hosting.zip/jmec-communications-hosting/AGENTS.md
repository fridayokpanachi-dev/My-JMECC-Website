<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Rules
- Portfolio photos and categories are maintained in the shared site catalogue with CDN asset pointers. Why: portfolio filters and detail pages use the same source without duplicating media.
- Website enquiries are inserted directly from the browser (insert-only public policy); files go to the private `enquiry-files` bucket. Why: no server round-trip needed, reads stay admin-only.
- Admin access uses `user_roles` + `has_role`; the first account created becomes admin via a trigger on sign-up. Why: lets the owner bootstrap without manual role edits.
- AI features call Lovable AI Gateway server-side only: streaming chat via `src/routes/api/chat.ts`, one-shot tools via `src/lib/ai.functions.ts`, shared prompt facts in `src/lib/ai/knowledge.ts` built from `src/lib/site.ts`. Why: keeps the key private and AI answers in sync with site facts.
- Visitor chat threads live in browser localStorage, each with its own `/chat/$threadId` page. Why: user chose separate conversations remembered per browser.
