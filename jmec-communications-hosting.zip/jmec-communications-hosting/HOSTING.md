# JMEC Communications — hosting guide

Everything needed to run this site on your own server. Read the three
"before you go live" items at the bottom first — they are the only things
that break when the site moves off Lovable's hosting.

## What is in this folder

| Path | What it is |
| --- | --- |
| `src/` | Every page, the enquiry form, the staff area, the AI features |
| `src/lib/site.ts` | Contact details, services, portfolio list, client strip |
| `src/assets/*.asset.json` | Pointers to the photos (see item 1 below) |
| `images/` | All 38 photos and company logos as real files |
| `drizzle/migrations/0000_enquiries_and_admin.sql` | The whole database setup |
| `public/` | Favicon, robots.txt |
| `.env` | Backend address and public key (both already visible to visitors) |
| `package.json`, `vite.config.ts`, `tsconfig.json` | Build settings |

## Requirements

- Node.js 20 or newer, and npm (or bun)
- A PostgreSQL database with Supabase's Auth and Storage schemas — the
  enquiry storage, staff sign-in and admin roles depend on them
- An internet connection at page load for the Google fonts (Bricolage
  Grotesque and Ubuntu), or self-host them

## 1. Install and run locally

```sh
npm install
npm run dev
```

The dev server prints its own address. To make the production bundle:

```sh
npm run build
```

By default the bundle is built for Cloudflare Workers. To run it on a plain
server or VPS instead, add the node preset to `vite.config.ts`:

```ts
export default defineConfig({
  tanstackStart: { server: { entry: "server" } },
  nitro: { preset: "node-server" },
});
```

Then `npm run build` and start it with `node .output/server/index.mjs`.

## 2. Environment settings

Create a `.env` file (or set these in your host's environment panel).

```
# Browser-visible — safe to publish
VITE_SUPABASE_URL=https://your-backend-url
VITE_SUPABASE_PUBLISHABLE_KEY=your-public-key

# Server-side only
SUPABASE_URL=https://your-backend-url
SUPABASE_PUBLISHABLE_KEY=your-public-key

# Only needed for the AI features
LOVABLE_API_KEY=your-ai-key
```

- Without the Supabase settings, the quote and contact forms cannot save and
  the staff area cannot sign in.
- Without `LOVABLE_API_KEY`, the chat assistant, quote helper and brand idea
  generator show "AI is not configured yet." — every other page still works.
- The privileged service key is **not** used by this site's code, so you do
  not need it.

## 3. Database setup

Run this file against your database, then create the upload folder:

```sh
psql "$DATABASE_URL" -f drizzle/migrations/0000_enquiries_and_admin.sql
```

That file creates: the `enquiries` table (insert-only for visitors, readable
only by admins), the `user_roles` table with the `has_role` check, the
trigger that makes the **first account ever created** the admin, and the
storage rules for uploaded artwork.

Then create a **private** storage bucket named `enquiry-files` with a 20 MB
per-file limit, and enable email-and-password sign-in.

Sign up once at `/auth` — that first account becomes the admin. Open
`/admin` to see enquiries. Later sign-ups get no access.

## 4. Hosting notes

- Routes work as-is. No redirect file, no hash router, no route table to
  edit. `/portfolio/prestige-branded-flask` and every other address resolve
  on the server.
- Uploaded artwork is read through short-lived signed links, so the bucket
  must stay private.
- The site's own address is written into search-result metadata and the
  sitemap — see the next section.

## Before you go live — three things to change

1. **Photos.** The pages point at Lovable's media server
   (`/__l5e/assets-v1/...`), which only exists on Lovable hosting. Off
   platform they would 404. All 38 files are in `images/` ready to be
   served — tell me and I will switch the site over to them so the folder
   stands on its own anywhere.
2. **Site address.** `SITE_URL` in `src/lib/seo.ts` and `BASE_URL` in
   `src/routes/sitemap[.]xml.ts` both still say
   `https://jmec-story-and-signal.lovable.app`. Set both to your real
   address (e.g. `https://www.jmeccomms.com.ng`) so search results and the
   sitemap point at the right place.
3. **AI features.** They call Lovable's AI gateway. Keep `LOVABLE_API_KEY`
   if that is fine, or point `src/lib/ai/gateway.server.ts` at another
   OpenAI-compatible provider — it only needs `baseURL`, `apiKey` and a
   model name.
