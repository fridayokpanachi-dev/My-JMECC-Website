# Roadmap
- [x] Add seven uploaded portfolio photos across suitable categories and update WhatsApp to 08086479092
- [x] Save enquiries and uploaded artwork securely
- [x] Staff sign-in and enquiries admin page
- [x] Show website www.jmeccomms.com.ng and email info@jmeccomms.com.ng
- [ ] Email each new enquiry to the team (needs owned sender domain, e.g. jmeccomms.com.ng)
- [x] AI: chat assistant, quote helper, brand idea generator, staff enquiry summaries
- [ ] Admin editing for projects, contact details and homepage text
- [x] Add two Prestige Assurance carry bag photos (Packaging Design, Branding and Brand Identity)
- [x] Client strip: drop GreenElec; Compass and TOFA on white cards with navy logos
