import { Link } from "@tanstack/react-router";
import { contact, serviceGroups, telHref } from "@/lib/site";
import { Logo } from "./Header";
import { btn } from "./ui";

export function Footer() {
  return (
    <footer className="border-t bg-secondary">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo />
          <p className="mt-4 font-display italic text-primary">{contact.tagline}</p>
          <p className="mt-3 text-sm text-muted-foreground">An independent, agile and people-driven creative agency in the heart of Lagos.</p>
        </div>
        <div>
          <h3 className="text-sm font-semibold">Services</h3>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {serviceGroups.map((g) => (
              <li key={g.id}><Link to="/services" hash={g.id} className="hover:text-primary">{g.title}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold">Company</h3>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-primary">About us</Link></li>
            <li><Link to="/portfolio" className="hover:text-primary">Our work</Link></li>
            <li><Link to="/approach" className="hover:text-primary">Our approach</Link></li>
            <li><Link to="/privacy" className="hover:text-primary">Privacy Policy</Link></li>
            <li><Link to="/terms" className="hover:text-primary">Terms of Use</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-sm font-semibold">Contact</h3>
          <address className="mt-4 space-y-2 text-sm not-italic text-muted-foreground">
            <p>{contact.address}</p>
            {contact.phones.map((p) => <p key={p}><a href={telHref(p)} className="hover:text-primary">{p}</a></p>)}
            <p><a href={`mailto:${contact.email}`} className="hover:text-primary">{contact.email}</a></p>
            <p><a href={`https://${contact.website}`} className="hover:text-primary">{contact.website}</a></p>
          </address>
          <Link to="/quote" className={btn({ variant: "primary" }) + " mt-5"}>Request a Quote</Link>
        </div>
      </div>
      <div className="border-t">
        <p className="mx-auto max-w-6xl px-5 py-5 text-xs text-muted-foreground">© {new Date().getFullYear()} JMEC Communications. All rights reserved.</p>
      </div>
    </footer>
  );
}
