import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import logo from "@/assets/jmec-mark.png";
import { btn } from "./ui";

export const navLinks = [
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Our Work" },
  { to: "/industries", label: "Industries" },
  { to: "/approach", label: "Approach" },
  { to: "/brand-ideas", label: "Brand Ideas" },
  { to: "/chat", label: "Ask JMEC" },
  { to: "/contact", label: "Contact" },
] as const;

export function Logo() {
  return (
    <Link to="/" className="flex shrink-0 items-center gap-2.5" aria-label="JMEC Communications home">
      <img src={logo} alt="JMEC Communications logo" className="h-14 w-auto" />
      <span className="font-display text-sm font-extrabold leading-tight tracking-wide text-primary sm:text-base">JMEC<br />COMMUNICATIONS</span>
    </Link>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-6 px-5">
        <Logo />
        <nav className="hidden items-center gap-6 lg:flex" aria-label="Main">
          {navLinks.map((l) => (
            <Link key={l.to} to={l.to} className="text-sm text-foreground/75 transition-colors hover:text-primary" activeProps={{ className: "!text-primary font-medium" }}>
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/quote" className={btn({ variant: "primary" }) + " hidden !py-2.5 sm:inline-flex"}>Request a Quote</Link>
          <button className="rounded-md p-2 lg:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label={open ? "Close menu" : "Open menu"}>
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="border-t bg-background px-5 pb-6 pt-2 lg:hidden" aria-label="Mobile">
          {navLinks.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="block border-b py-3 text-lg font-display">{l.label}</Link>
          ))}
          <Link to="/quote" onClick={() => setOpen(false)} className={btn({ variant: "primary" }) + " mt-5 w-full"}>Request a Quote</Link>
        </nav>
      )}
    </header>
  );
}
