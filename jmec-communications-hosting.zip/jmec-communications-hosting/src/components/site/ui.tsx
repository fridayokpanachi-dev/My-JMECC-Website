import { Link } from "@tanstack/react-router";
import { cva, type VariantProps } from "class-variance-authority";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export const btn = cva(
  "inline-flex items-center justify-center gap-2 rounded-md px-5 py-3 text-sm font-medium transition-all duration-200 disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-primary text-primary-foreground hover:bg-navy hover:-translate-y-0.5",
        outline: "border border-foreground/20 text-foreground hover:border-primary hover:text-primary",
        light: "bg-navy-foreground text-navy hover:bg-primary hover:text-primary-foreground",
        ghostLight: "border border-navy-foreground/40 text-navy-foreground hover:bg-navy-foreground/10",
      },
    },
    defaultVariants: { variant: "primary" },
  },
);
export type BtnVariant = VariantProps<typeof btn>["variant"];

export function PageHero({ eyebrow, title, intro, children }: { eyebrow: string; title: ReactNode; intro?: string; children?: ReactNode }) {
  return (
    <section className="notch bg-navy text-navy-foreground">
      <div className="mx-auto max-w-6xl px-5 pb-16 pt-20 md:pb-24 md:pt-28">
        <p className="eyebrow !text-sky animate-rise">{eyebrow}</p>
        <h1 className="mt-4 max-w-3xl text-4xl font-bold leading-[1.05] md:text-6xl animate-rise">{title}</h1>
        {intro && <p className="mt-6 max-w-2xl text-lg text-navy-foreground/80">{intro}</p>}
        {children}
      </div>
    </section>
  );
}

export function SectionHead({ eyebrow, title, text, className }: { eyebrow: string; title: string; text?: string; className?: string }) {
  return (
    <div className={cn("max-w-2xl", className)}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-bold md:text-4xl">{title}</h2>
      {text && <p className="mt-4 text-muted-foreground">{text}</p>}
    </div>
  );
}

export function ClosingCta() {
  return (
    <section className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-20 md:grid-cols-[1.4fr_1fr] md:items-end">
        <div>
          <h2 className="text-4xl font-bold leading-tight md:text-5xl">Let Us Help Position <span className="text-sky">Your Brand.</span></h2>
          <p className="mt-5 max-w-xl text-ink-foreground/75">From creative concepts to finished branding and print solutions, let's build a brand experience that makes your business memorable.</p>
        </div>
        <div className="flex flex-wrap gap-3 md:justify-end">
          <Link to="/quote" className={btn({ variant: "primary" })}>Request a Quote</Link>
          <Link to="/contact" className={btn({ variant: "ghostLight" })}>Contact Our Team</Link>
        </div>
      </div>
    </section>
  );
}
