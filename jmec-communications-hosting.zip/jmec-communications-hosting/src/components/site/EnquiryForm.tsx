import { CheckCircle2, Loader2, MessageCircle, Wand2 } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { improveQuote } from "@/lib/ai.functions";
import { supabase } from "@/integrations/supabase/client";
import { quoteServices, whatsappHref, openWhatsApp } from "@/lib/site";
import { btn } from "./ui";

type Errors = Record<string, string>;
const field = "mt-1.5 w-full rounded-md border bg-card px-3 py-2.5 text-sm";
const MAX_FILES = 5;
const MAX_BYTES = 20 * 1024 * 1024;

function makeRef() {
  const d = new Date();
  return `JMEC-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

/** Enquiry form: saves the enquiry (and any attached files) securely for the JMEC team. */
export function EnquiryForm({ mode, defaultService }: { mode: "quote" | "contact"; defaultService?: string | undefined }) {
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ ref: string; body: string } | null>(null);
  const msgRef = useRef<HTMLTextAreaElement>(null);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiMsg, setAiMsg] = useState<string | null>(null);
  const improveFn = useServerFn(improveQuote);

  async function improve() {
    const el = msgRef.current;
    if (!el) return;
    const draft = el.value.trim();
    if (draft.length < 3) return setAiMsg("Write a few words about your project first.");
    const service = (el.form?.elements.namedItem("service") as HTMLSelectElement | null)?.value ?? "";
    setAiBusy(true); setAiMsg(null);
    try {
      const r = await improveFn({ data: { service, draft } });
      el.value = r.text;
      setAiMsg("Done — check it and edit anything before sending.");
    } catch (err) {
      setAiMsg(err instanceof Error ? err.message : "Couldn't improve it right now.");
    } finally {
      setAiBusy(false);
    }
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    if (f.get("website")) return; // honeypot
    const v = (k: string) => String(f.get(k) ?? "").trim();
    const files = (f.getAll("files") as File[]).filter((x) => x.size > 0);
    const errs: Errors = {};
    if (v("name").length < 2) errs["name"] = "Please enter your full name.";
    if (!/^\S+@\S+\.\S+$/.test(v("email"))) errs["email"] = "Please enter a valid email address.";
    if (mode === "quote" && !/^[+\d][\d\s-]{6,}$/.test(v("phone"))) errs["phone"] = "Please enter a valid phone number.";
    if (mode === "quote" && !v("service")) errs["service"] = "Please choose a service.";
    if (v("message").length < 10) errs["message"] = "Please tell us a little more (at least 10 characters).";
    if (files.length > MAX_FILES) errs["files"] = `Please attach up to ${MAX_FILES} files.`;
    else if (files.some((x) => x.size > MAX_BYTES)) errs["files"] = "Each file must be 20 MB or smaller.";
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy(true);
    const ref = makeRef();
    try {
      const paths: string[] = [];
      for (const file of files) {
        const path = `${ref}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
        const { error } = await supabase.storage.from("enquiry-files").upload(path, file);
        if (error) throw error;
        paths.push(path);
      }
      const opt = (k: string) => v(k) || null;
      const { error } = await supabase.from("enquiries").insert({
        reference: ref, kind: mode, name: v("name"), company: opt("company"), email: v("email"), phone: opt("phone"),
        service: opt("service"), quantity: opt("quantity"), specs: opt("specs"), preferred_date: opt("date"),
        budget: opt("budget"), contact_method: opt("contactMethod"), message: v("message"), files: paths,
      });
      if (error) throw error;
      const body = [["Reference", ref], ["Name", v("name")], ["Service", v("service")], ["Details", v("message")]]
        .filter(([, x]) => x).map(([k, x]) => `${k}: ${x}`).join("\n");
      setDone({ ref, body });
    } catch (err) {
      console.error(err);
      setErrors({ form: "Sorry, we couldn't send your enquiry. Please try again, or call or WhatsApp us." });
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="rounded-md border bg-card p-8" role="status">
        <CheckCircle2 className="size-10 text-primary" />
        <h3 className="mt-4 text-2xl font-bold">Thank you — we've received your enquiry</h3>
        <p className="mt-2 text-muted-foreground">Your reference is <strong className="text-foreground">{done.ref}</strong>. Our team will get back to you soon.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <a href={whatsappHref(done.body)} onClick={(e) => openWhatsApp(e, done.body)} target="_blank" rel="noopener noreferrer" className={btn({ variant: "outline" })}><MessageCircle className="size-4" /> Follow up on WhatsApp</a>
          <button onClick={() => setDone(null)} className={btn({ variant: "outline" })}>Start a new enquiry</button>
        </div>
      </div>
    );
  }

  const Err = ({ k }: { k: string }) => errors[k] ? <p id={`${k}-err`} className="mt-1 text-xs text-destructive">{errors[k]}</p> : null;
  const aria = (k: string) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-err` : undefined });

  return (
    <form onSubmit={submit} noValidate className="grid gap-5 rounded-md border bg-card p-6 sm:grid-cols-2 md:p-8">
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <label className="text-sm font-medium">Full name *<input name="name" autoComplete="name" className={field} {...aria("name")} /><Err k="name" /></label>
      <label className="text-sm font-medium">Company or organization<input name="company" autoComplete="organization" className={field} /></label>
      <label className="text-sm font-medium">Email address *<input name="email" type="email" autoComplete="email" className={field} {...aria("email")} /><Err k="email" /></label>
      <label className="text-sm font-medium">Phone number {mode === "quote" && "*"}<input name="phone" type="tel" autoComplete="tel" className={field} {...aria("phone")} /><Err k="phone" /></label>
      {mode === "quote" && (
        <>
          <label className="text-sm font-medium">Service required *
            <select name="service" defaultValue={defaultService ?? ""} className={field} {...aria("service")}>
              <option value="">Choose a service…</option>
              {quoteServices.map((s) => <option key={s}>{s}</option>)}
            </select><Err k="service" />
          </label>
          <label className="text-sm font-medium">Quantity (if applicable)<input name="quantity" className={field} /></label>
          <label className="text-sm font-medium">Dimensions or specifications<input name="specs" className={field} /></label>
          <label className="text-sm font-medium">Preferred delivery date<input name="date" type="date" className={field} /></label>
          <label className="text-sm font-medium">Budget range (optional)
            <select name="budget" className={field} defaultValue="">
              <option value="">Prefer not to say</option>
              <option>Under ₦250,000</option><option>₦250,000 – ₦1,000,000</option><option>₦1,000,000 – ₦5,000,000</option><option>Above ₦5,000,000</option>
            </select>
          </label>
          <label className="text-sm font-medium">Preferred contact method
            <select name="contactMethod" className={field}><option>Email</option><option>Phone call</option><option>WhatsApp</option></select>
          </label>
        </>
      )}
      <label className="text-sm font-medium sm:col-span-2">{mode === "quote" ? "Project description *" : "Message *"}
        <textarea ref={msgRef} name="message" rows={mode === "quote" ? 8 : 5} className={field} {...aria("message")} /><Err k="message" />
        {mode === "quote" && (
          <span className="mt-2 flex flex-wrap items-center gap-3">
            <button type="button" onClick={improve} disabled={aiBusy} className="inline-flex items-center gap-1.5 rounded-md border border-primary px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary hover:text-primary-foreground disabled:opacity-50">
              {aiBusy ? <Loader2 className="size-3.5 animate-spin" /> : <Wand2 className="size-3.5" />} {aiBusy ? "Improving…" : "Improve my description with AI"}
            </button>
            {aiMsg && <span className="text-xs text-muted-foreground">{aiMsg}</span>}
          </span>
        )}
      </label>
      {mode === "quote" && (
        <label className="text-sm font-medium sm:col-span-2">Artwork or reference files (optional, up to 5 files, 20 MB each)
          <input name="files" type="file" multiple className={field} {...aria("files")} /><Err k="files" />
        </label>
      )}
      <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
        <button type="submit" disabled={busy} className={btn({ variant: "primary" })}>
          {busy && <Loader2 className="size-4 animate-spin" />}{mode === "quote" ? "Send quote request" : "Send message"}
        </button>
        <Err k="form" />
      </div>
    </form>
  );
}
