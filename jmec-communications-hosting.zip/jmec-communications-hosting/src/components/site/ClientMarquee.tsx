import { SectionHead } from "./ui";
import { clients } from "@/lib/site";

export function ClientMarquee() {
  return (
    <section className="border-t bg-secondary">
      <div className="mx-auto max-w-6xl px-5 py-20">
        <SectionHead eyebrow="Our clients" title="Who we work with" text="Brands and organizations we have had the privilege of serving." className="mx-auto text-center" />
        <div className="relative mt-12 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
          <div className="flex w-max gap-4 animate-drift-slow hover:[animation-play-state:paused]">
            {[...clients, ...clients].map((c, i) => (
              <div
                key={`${c.name}-${i}`}
                aria-hidden={i >= clients.length}
                className={`flex h-24 w-56 shrink-0 items-center justify-center rounded-md p-5 ring-1 ring-border ${c.dark ? "bg-primary" : "bg-card"}`}
              >
                {c.logo ? (
                  <img src={c.logo} alt={i < clients.length ? `${c.name} logo` : ""} title={c.name} loading="lazy" className="max-h-full max-w-full object-contain" />
                ) : (
                  <span className="text-center font-display text-lg font-bold leading-tight">{c.name}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
