import { Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { categories, projects } from "@/lib/site";
import { cn } from "@/lib/utils";

export function PortfolioGrid({ limit, search, className }: { limit?: number; search?: boolean; className?: string }) {
  const [cat, setCat] = useState<string>("All");
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    let l = projects.filter((p) => (cat === "All" || p.category === cat) && (!limit || !p.placeholder));
    if (q.trim()) {
      const t = q.toLowerCase();
      l = l.filter((p) => [p.title, p.category, p.description, ...p.services].join(" ").toLowerCase().includes(t));
    }
    return limit ? l.slice(0, limit) : l;
  }, [cat, q, limit]);

  return (
    <div className={className}>
      <div className="flex flex-col gap-4">
        {search && (
          <label className="relative max-w-sm">
            <span className="sr-only">Search projects</span>
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search projects…" className="w-full rounded-md border bg-card py-2.5 pl-9 pr-3 text-sm" />
          </label>
        )}
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          {["All", ...categories].map((c) => (
            <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
              className={cn("rounded-full border px-4 py-1.5 text-xs transition-colors", cat === c ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-primary hover:text-primary")}>
              {c}
            </button>
          ))}
        </div>
      </div>
      {list.length === 0 ? (
        <p className="mt-10 text-muted-foreground">No projects in this category yet.</p>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <Link key={p.slug} to="/portfolio/$slug" params={{ slug: p.slug }} className="group block">
              <div className={cn("overflow-hidden rounded-md", p.fit === "contain" ? "bg-card ring-1 ring-border" : "bg-muted")}>
                <img src={p.image} alt={p.title} loading="lazy" className={cn("aspect-[4/3] w-full transition-transform duration-500 group-hover:scale-105", p.fit === "contain" ? "object-contain" : "object-cover", p.placeholder && "opacity-40 grayscale")} />
              </div>
              <p className="eyebrow mt-4 !text-[0.65rem]">{p.category}</p>
              <h3 className="mt-1 text-lg font-bold group-hover:text-primary">{p.title}</h3>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
