import { afterEach, describe, expect, it, vi } from "vitest";
import { contact, openWhatsApp, whatsappHref } from "@/lib/site";

afterEach(() => vi.restoreAllMocks());

describe("Website WhatsApp contact", () => {
  it("shows the email and website the owner gave", () => {
    expect(contact.email).toBe("info@jmeccomms.com.ng");
    expect(contact.website).toBe("www.jmeccomms.com.ng");
  });


  it("uses 08086479092 in international format for chat links", () => {
    expect(contact.whatsapp).toBe("2348086479092");
    expect(whatsappHref("Hello JMEC")).toBe("https://wa.me/2348086479092?text=Hello%20JMEC");
  });

  it("opens desktop chats directly at the designated number", () => {
    vi.spyOn(window.navigator, "userAgent", "get").mockReturnValue("Desktop browser");
    const open = vi.spyOn(window, "open").mockReturnValue({} as Window);
    const preventDefault = vi.fn();
    openWhatsApp({ preventDefault }, "Hello JMEC");
    expect(preventDefault).toHaveBeenCalledOnce();
    expect(open).toHaveBeenCalledWith("https://web.whatsapp.com/send?phone=2348086479092&text=Hello%20JMEC", "_blank", "noopener,noreferrer");
  });
});