import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { btn, PageHero } from "@/components/site/ui";

export const Route = createFileRoute("/auth")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Staff sign in — JMEC Communications" },
      { name: "description", content: "Sign in to the JMEC Communications staff area." },
      { property: "og:title", content: "Staff sign in — JMEC Communications" },
      { property: "og:description", content: "Sign in to the JMEC Communications staff area." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Auth,
});

const field = "mt-1.5 w-full rounded-md border bg-card px-3 py-2.5 text-sm";

function Auth() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email")), password = String(f.get("password"));
    setBusy(true); setMsg(null);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setBusy(false);
      if (error) return setMsg(error.message);
      navigate({ to: "/admin" });
    } else {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/admin` } });
      setBusy(false);
      setMsg(error ? error.message : "Check your email to confirm your account, then sign in.");
    }
  }

  return (
    <>
      <PageHero eyebrow="Staff area" title={mode === "in" ? "Sign in" : "Create staff account"} />
      <section className="mx-auto max-w-md px-5 py-16">
        <form onSubmit={submit} className="grid gap-5 rounded-md border bg-card p-6">
          <label className="text-sm font-medium">Email<input name="email" type="email" required autoComplete="email" className={field} /></label>
          <label className="text-sm font-medium">Password<input name="password" type="password" required minLength={8} autoComplete={mode === "in" ? "current-password" : "new-password"} className={field} /></label>
          <button disabled={busy} className={btn({ variant: "primary" })}>{mode === "in" ? "Sign in" : "Create account"}</button>
          {msg && <p className="text-sm text-muted-foreground" role="status">{msg}</p>}
          <button type="button" onClick={() => { setMode(mode === "in" ? "up" : "in"); setMsg(null); }} className="text-sm text-primary">
            {mode === "in" ? "No account yet? Create one" : "Already have an account? Sign in"}
          </button>
        </form>
      </section>
    </>
  );
}
