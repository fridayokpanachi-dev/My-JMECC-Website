import { createFileRoute } from "@tanstack/react-router";
import { ClosingCta, PageHero } from "@/components/site/ui";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/approach")({
  staticData: { sitemap: true },
  head: () => seo("Our Approach: Strategy, Research, Execution — JMEC", "How JMEC Communications studies each client's business, audience and market before creating tailored brand solutions.", "/approach"),
  component: Approach,
});

const stages = [
  { name: "Strategy", text: "We start with your objectives — what the brand must achieve, for whom, and how success will be judged." },
  { name: "Research", text: "We study the client, the product and the market: audience, competitors, challenges past, present and future, and business realities." },
  { name: "Execution", text: "We design and implement tailored solutions across print, signage, environments and digital — tested against our five design criteria." },
];

function Approach() {
  return (
    <>
      <PageHero eyebrow="Our approach" title="Strategy → Research → Execution" intro="Every project begins with understanding before creating. That's our mantra." />
      <section className="mx-auto max-w-6xl px-5 py-20">
        <ol className="relative grid gap-10 md:grid-cols-3">
          {stages.map((s, i) => (
            <li key={s.name} className="relative">
              <div className={`flex size-20 items-center justify-center rounded-full font-display text-2xl font-bold ${i === 1 ? "bg-navy text-navy-foreground" : "bg-primary text-primary-foreground"}`}>{i + 1}</div>
              <h2 className="mt-6 text-3xl font-bold">{s.name}</h2>
              <p className="mt-3 text-muted-foreground">{s.text}</p>
            </li>
          ))}
        </ol>
        <blockquote className="mt-20 border-l-4 border-primary pl-6 font-display text-2xl md:text-3xl">
          "We combine insight about our clients' market and their brand attributes to create solutions that build trust."
        </blockquote>
      </section>
      <ClosingCta />
    </>
  );
}
