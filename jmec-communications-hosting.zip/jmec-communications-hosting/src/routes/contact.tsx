import { createFileRoute } from "@tanstack/react-router";
import { Globe, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { EnquiryForm } from "@/components/site/EnquiryForm";
import { btn, PageHero } from "@/components/site/ui";
import { contact, telHref, whatsappHref, openWhatsApp } from "@/lib/site";

const waText = "Hello JMEC Communications, I'd like to talk about my brand.";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  staticData: { sitemap: true },
  head: () => seo("Contact JMEC Communications — Surulere, Lagos", "Call, email or WhatsApp JMEC Communications at 13 Aiyetoro Street, Aguda Surulere, Lagos.", "/contact"),
  component: Contact,
});

function Contact() {
  const map = encodeURIComponent(contact.address);
  return (
    <>
      <PageHero eyebrow="Contact us" title="Let's talk about your brand" />
      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-[1fr_1.3fr]">
        <div className="space-y-6">
          <div className="flex gap-4"><MapPin className="mt-1 size-5 shrink-0 text-primary" /><div><h2 className="font-bold">Visit</h2><p className="text-muted-foreground">{contact.address}</p></div></div>
          <div className="flex gap-4"><Phone className="mt-1 size-5 shrink-0 text-primary" /><div><h2 className="font-bold">Call</h2>{contact.phones.map((p) => <a key={p} href={telHref(p)} className="block text-muted-foreground hover:text-primary">{p}</a>)}</div></div>
          <div className="flex gap-4"><Mail className="mt-1 size-5 shrink-0 text-primary" /><div><h2 className="font-bold">Email</h2><a href={`mailto:${contact.email}`} className="text-muted-foreground hover:text-primary">{contact.email}</a></div></div>
          <div className="flex gap-4"><Globe className="mt-1 size-5 shrink-0 text-primary" /><div><h2 className="font-bold">Website</h2><a href={`https://${contact.website}`} className="text-muted-foreground hover:text-primary">{contact.website}</a></div></div>
          <a href={whatsappHref(waText)} onClick={(e) => openWhatsApp(e, waText)} target="_blank" rel="noopener noreferrer" className={btn({ variant: "primary" })}><MessageCircle className="size-4" /> Chat on WhatsApp</a>
          <iframe title="Map to JMEC Communications" src={`https://maps.google.com/maps?q=${map}&output=embed`} loading="lazy" className="h-72 w-full rounded-md border" />
          <a href={`https://www.google.com/maps/search/?api=1&query=${map}`} target="_blank" rel="noreferrer" className="text-sm text-primary">Open in Google Maps →</a>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Send us a message</h2>
          <div className="mt-6"><EnquiryForm mode="contact" /></div>
        </div>
      </section>
    </>
  );
}
