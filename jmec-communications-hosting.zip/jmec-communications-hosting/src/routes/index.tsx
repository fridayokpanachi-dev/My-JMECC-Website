import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { btn, ClosingCta, SectionHead } from "@/components/site/ui";
import { ClientMarquee } from "@/components/site/ClientMarquee";
import { PortfolioGrid } from "@/components/site/PortfolioGrid";
import { homeServices, images, industries, values } from "@/lib/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/")({
  staticData: { sitemap: true },
  head: () => seo("JMEC Communications — We Brand Beyond Comparison | Lagos", "Branding, printing, signage, vehicle branding and digital communication solutions from a creative agency in Surulere, Lagos.", "/"),
  component: Home,
});

const showcase = [images.vehicle, images.interiors, images.branding, images.pos, images.web, images.design, images.responsive, images.social];

function Home() {
  return (
    <>
      <section className="notch relative overflow-hidden bg-navy text-navy-foreground">
        <div className="mx-auto grid max-w-6xl gap-12 px-5 pb-10 pt-20 md:grid-cols-[1.2fr_1fr] md:pt-28">
          <div>
            <p className="eyebrow !text-sky animate-rise">Creative agency · Lagos, Nigeria</p>
            <h1 className="mt-5 text-5xl font-extrabold leading-[0.98] md:text-7xl animate-rise">We Brand <span className="text-sky">Beyond</span> Comparison.</h1>
            <p className="mt-6 max-w-xl text-lg text-navy-foreground/80 animate-rise">Creative branding, professional printing, signage and digital communication solutions designed to help your business stand out, connect with customers and grow.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link to="/quote" className={btn({ variant: "light" })}>Request a Quote <ArrowRight className="size-4" /></Link>
              <Link to="/portfolio" className={btn({ variant: "ghostLight" })}>Explore Our Work</Link>
            </div>
          </div>
          <div className="relative hidden md:block">
            <img src={images.collage} alt="Collage of JMEC brand identity, display and print work" className="aspect-square w-full rounded-md object-cover shadow-lift" />
          </div>
        </div>
        <div className="overflow-hidden py-10" aria-hidden>
          <div className="flex w-max gap-4 animate-drift">
            {[...showcase, ...showcase].map((src, i) => (
              <img key={i} src={src} alt="" loading="lazy" className="h-40 w-72 rounded-md object-cover opacity-90 md:h-52 md:w-96" />
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead eyebrow="What we do" title="Branding solutions from concept to finish" />
          <Link to="/services" className={btn({ variant: "outline" })}>All services</Link>
        </div>
        <div className="mt-12 grid gap-px overflow-hidden rounded-md border bg-border sm:grid-cols-2 lg:grid-cols-5">
          {homeServices.map((s, i) => (
            <Link key={s.title} to="/services" hash={s.group} className="group flex flex-col bg-card p-6 transition-colors hover:bg-navy hover:text-navy-foreground">
              <span className="font-display text-sm text-primary group-hover:text-sky">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-6 text-lg font-bold leading-snug">{s.title}</h3>
              <p className="mt-3 flex-1 text-sm text-muted-foreground group-hover:text-navy-foreground/75">{s.text}</p>
              <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary group-hover:text-sky">Learn more <ArrowUpRight className="size-4" /></span>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-secondary">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-24 md:grid-cols-2">
          <img src={images.branding} alt="Brand identity development and business card design" loading="lazy" className="w-full rounded-md object-cover shadow-lift" />
          <div>
            <SectionHead eyebrow="About JMEC" title="Independent, agile and people-driven" />
            <p className="mt-5 text-muted-foreground">JMEC Communications is an independent, agile and people-driven creative agency based in the heart of Lagos. Our team creates visually engaging and thought-provoking designs. We provide capabilities in design, content development and implementation that shape perception and connect brands with customers.</p>
            <p className="mt-4 text-muted-foreground">Using our creativity and strategic resources, we offer custom-made solutions that consider the uniqueness of each brand and its objectives. Before recommending solutions, we carefully study the client, the product and the market.</p>
            <Link to="/about" className={btn({ variant: "primary" }) + " mt-8"}>About Us</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24">
        <SectionHead eyebrow="Our work" title="Featured portfolio" text="Selected work from our corporate profile. Filter by category." />
        <PortfolioGrid className="mt-10" limit={6} />
        <Link to="/portfolio" className={btn({ variant: "outline" }) + " mt-10"}>View full portfolio</Link>
      </section>

      <section className="notch bg-navy text-navy-foreground">
        <div className="mx-auto max-w-6xl px-5 py-24">
          <p className="eyebrow !text-sky">Why choose JMEC</p>
          <h2 className="mt-3 max-w-2xl text-3xl font-bold md:text-4xl">Five values guide every brief and every relationship</h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-5">
            {values.map((v) => (
              <div key={v.name} className="border-t border-navy-foreground/25 pt-5">
                <h3 className="text-xl font-bold">{v.name}</h3>
                <p className="mt-3 text-sm text-navy-foreground/75">{v.text}</p>
              </div>
            ))}
          </div>
          <p className="mt-12 font-display text-2xl">Our clients, <span className="text-sky">our pride.</span></p>
        </div>
      </section>

      <ClientMarquee />

      <section className="mx-auto max-w-6xl px-5 py-24">
        <SectionHead eyebrow="Our approach" title="Strategy → Research → Execution" text="Every project begins with understanding the client's business, audience, challenges, market realities and objectives — before we develop and implement a tailored creative solution." />
        <ol className="mt-12 grid gap-4 md:grid-cols-3">
          {["Strategy", "Research", "Execution"].map((s, i) => (
            <li key={s} className={`rounded-md p-8 ${i === 1 ? "bg-navy text-navy-foreground" : "bg-primary text-primary-foreground"}`}>
              <span className="font-display text-sm opacity-75">Stage {i + 1}</span>
              <p className="mt-10 font-display text-3xl font-bold">{s}</p>
            </li>
          ))}
        </ol>
        <Link to="/approach" className="mt-8 inline-flex items-center gap-1 text-sm font-medium text-primary">How we work <ArrowRight className="size-4" /></Link>
      </section>

      <section className="border-t bg-secondary">
        <div className="mx-auto max-w-6xl px-5 py-24">
          <SectionHead eyebrow="Who we serve" title="Industries we work with" />
          <div className="mt-10 flex flex-wrap gap-3">
            {industries.map((i) => (
              <Link key={i.name} to="/industries" className="rounded-full border bg-card px-5 py-3 text-sm transition-colors hover:border-primary hover:text-primary">{i.name}</Link>
            ))}
          </div>
        </div>
      </section>

      <ClosingCta />
    </>
  );
}
