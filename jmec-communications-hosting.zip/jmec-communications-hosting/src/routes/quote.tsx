import { createFileRoute } from "@tanstack/react-router";
import { EnquiryForm } from "@/components/site/EnquiryForm";
import { PageHero } from "@/components/site/ui";
import { quoteServices } from "@/lib/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/quote")({
  staticData: { sitemap: true },
  validateSearch: (s: Record<string, unknown>): { service?: string | undefined } => ({
    service: typeof s["service"] === "string" && quoteServices.includes(s["service"]) ? s["service"] : undefined,
  }),
  head: () => seo("Request a Quote — JMEC Communications", "Request a quote for branding, printing, signage, vehicle branding, packaging, digital or event branding in Lagos.", "/quote"),
  component: Quote,
});

function Quote() {
  const { service } = Route.useSearch();
  return (
    <>
      <PageHero eyebrow="Request a quote" title="Tell us about your project" intro="Share a few details and our team will get back to you with next steps and pricing." />
      <section className="mx-auto max-w-4xl px-5 py-16">
        <EnquiryForm mode="quote" defaultService={service} />
      </section>
    </>
  );
}
