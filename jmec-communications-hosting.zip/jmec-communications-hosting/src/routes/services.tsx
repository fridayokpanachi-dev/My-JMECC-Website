import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { btn, ClosingCta, PageHero } from "@/components/site/ui";
import { serviceGroups } from "@/lib/site";
import { seo } from "@/lib/seo";

const quoteMap: Record<string, string> = { branding: "Branding", printing: "Printing", signage: "Signage", digital: "Digital design", events: "Event branding" };

export const Route = createFileRoute("/services")({
  staticData: { sitemap: true },
  head: () => seo("Branding, Printing & Signage Services in Lagos — JMEC", "Brand identity, commercial printing, signage, vehicle branding, websites, social media and event branding services in Lagos.", "/services"),
  component: Services,
});

function Services() {
  return (
    <>
      <PageHero eyebrow="Services" title="Everything your brand needs to be seen and remembered" intro="Five groups of capabilities, delivered with the same strategic care: study first, then create." />
      {serviceGroups.map((g, i) => (
        <section key={g.id} id={g.id} className={`scroll-mt-20 ${i % 2 ? "bg-secondary" : ""}`}>
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:grid-cols-2">
            <img src={g.image} alt={g.title} loading="lazy" className={`w-full rounded-md object-cover shadow-lift ${i % 2 ? "md:order-2" : ""}`} />
            <div>
              <p className="eyebrow">{String(i + 1).padStart(2, "0")}</p>
              <h2 className="mt-3 text-3xl font-bold">{g.title}</h2>
              <p className="mt-4 text-muted-foreground">{g.intro}</p>
              <ul className="mt-6 space-y-2">
                {g.items.map((it) => <li key={it} className="flex gap-3 text-sm"><Check className="size-4 shrink-0 translate-y-0.5 text-primary" />{it}</li>)}
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/quote" search={{ service: quoteMap[g.id] }} className={btn({ variant: "primary" })}>Request a Quote</Link>
                <Link to="/contact" className={btn({ variant: "outline" })}>Discuss this service</Link>
              </div>
            </div>
          </div>
        </section>
      ))}
      <ClosingCta />
    </>
  );
}
