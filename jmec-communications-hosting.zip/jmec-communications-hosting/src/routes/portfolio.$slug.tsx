import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, X } from "lucide-react";
import { useEffect, useState } from "react";
import { btn, ClosingCta } from "@/components/site/ui";
import { projects } from "@/lib/site";
import { cn } from "@/lib/utils";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/portfolio/$slug")({
  staticData: { sitemap: true },
  loader: ({ params }) => {
    const project = projects.find((p) => p.slug === params.slug);
    if (!project) throw notFound();
    return project;
  },
  head: ({ params, loaderData }) =>
    loaderData ? seo(`${loaderData.title} — JMEC Communications`, loaderData.description.slice(0, 155), `/portfolio/${params.slug}`) : { meta: [{ title: "Project not found — JMEC" }, { name: "robots", content: "noindex" }] },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-5 py-32 text-center">
      <h1 className="text-4xl font-bold">Project not found</h1>
      <Link to="/portfolio" className={btn({ variant: "primary" }) + " mt-6"}>Back to portfolio</Link>
    </div>
  ),
  component: ProjectPage,
});

function ProjectPage() {
  const p = Route.useLoaderData();
  const [zoom, setZoom] = useState(false);
  const related = projects.filter((x) => x.slug !== p.slug && !x.placeholder).sort((a) => (a.category === p.category ? -1 : 1)).slice(0, 3);

  // Lock body scroll while the zoom overlay is open
  useEffect(() => {
    if (!zoom) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setZoom(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [zoom]);

  return (
    <>
      <section className="mx-auto max-w-6xl px-5 py-12">
        <Link to="/portfolio" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="size-4" /> All work</Link>
        <p className="eyebrow mt-8">{p.category}</p>
        <h1 className="mt-2 text-4xl font-bold md:text-5xl">{p.title}</h1>
        <button onClick={() => setZoom(true)} className="mt-10 block w-full overflow-hidden rounded-md bg-muted" aria-label="View image larger">
          <img
            src={p.image}
            alt={p.title}
            className={cn("block w-full", p.fit === "contain" ? "max-h-[80vh] object-contain bg-card" : "aspect-[16/9] object-cover")}
          />
        </button>
        <div className="mt-10 grid gap-10 md:grid-cols-[2fr_1fr]">
          <p className="text-lg text-muted-foreground">{p.description}</p>
          <dl className="space-y-4 text-sm">
            {p.client && <div><dt className="font-semibold">Client</dt><dd className="text-muted-foreground">{p.client}</dd></div>}
            <div><dt className="font-semibold">Services delivered</dt><dd className="text-muted-foreground">{p.services.join(", ")}</dd></div>
          </dl>
        </div>
      </section>
      {zoom && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/95 p-4"
          role="dialog"
          aria-modal="true"
          aria-label={`${p.title} — enlarged view`}
          onClick={() => setZoom(false)}
        >
          <button
            onClick={() => setZoom(false)}
            className="absolute right-4 top-4 text-ink-foreground"
            aria-label="Close enlarged view"
          >
            <X className="size-8" />
          </button>
          <img src={p.image} alt={p.title} className="max-h-full max-w-full object-contain" />
        </div>
      )}
      <section className="mx-auto max-w-6xl px-5 pb-20">
        <h2 className="text-2xl font-bold">Related projects</h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-3">
          {related.map((r) => (
            <Link key={r.slug} to="/portfolio/$slug" params={{ slug: r.slug }} className="group">
              <img src={r.image} alt={r.title} loading="lazy" className={cn("aspect-[4/3] w-full rounded-md", r.fit === "contain" ? "bg-card object-contain ring-1 ring-border" : "object-cover")} />
              <h3 className="mt-3 font-bold group-hover:text-primary">{r.title}</h3>
            </Link>
          ))}
        </div>
      </section>
      <ClosingCta />
    </>
  );
}
