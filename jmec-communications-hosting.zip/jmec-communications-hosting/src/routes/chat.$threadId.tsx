import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { MessagesSquare, Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Conversation, ConversationContent, ConversationEmptyState, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputBody, PromptInputFooter, PromptInputSubmit, PromptInputTextarea } from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { createThread, deleteThread, getThread, loadThreads, saveMessages, type Thread } from "@/lib/chat-threads";
import { cn } from "@/lib/utils";
import mark from "@/assets/jmec-mark.png";

export const Route = createFileRoute("/chat/$threadId")({
  staticData: { sitemap: false },
  ssr: false,
  head: () => ({
    meta: [
      { title: "Ask JMEC — AI assistant | JMEC Communications" },
      { name: "description", content: "Chat with the JMEC Communications AI assistant about services, quotes and contact details." },
      { property: "og:title", content: "Ask JMEC — AI assistant" },
      { property: "og:description", content: "Instant answers about JMEC Communications services in Lagos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ChatPage,
});

const starters = ["What services do you offer?", "I need signage for my shop", "How do I request a quote?", "Where are you located?"];

function useThreads() {
  const [threads, setThreads] = useState<Thread[]>(() => loadThreads());
  useEffect(() => {
    const on = () => setThreads(loadThreads());
    window.addEventListener("jmec-threads", on);
    return () => window.removeEventListener("jmec-threads", on);
  }, []);
  return threads;
}

function ChatPage() {
  const { threadId } = Route.useParams();
  const navigate = useNavigate();
  const threads = useThreads();
  const newChat = () => navigate({ to: "/chat/$threadId", params: { threadId: createThread().id } });
  const remove = (id: string) => {
    deleteThread(id);
    if (id === threadId) {
      const next = loadThreads()[0] ?? createThread();
      navigate({ to: "/chat/$threadId", params: { threadId: next.id }, replace: true });
    }
  };

  return (
    <section className="mx-auto grid max-w-6xl gap-6 px-5 py-8 md:grid-cols-[240px_1fr]">
      <aside className="flex flex-col gap-2 md:border-r md:pr-4">
        <button onClick={newChat} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"><Plus className="size-4" /> New conversation</button>
        <ul className="flex gap-2 overflow-x-auto md:flex-col md:overflow-visible">
          {threads.map((t) => (
            <li key={t.id} className={cn("group flex shrink-0 items-center rounded-md text-sm", t.id === threadId ? "bg-secondary" : "hover:bg-muted")}>
              <Link to="/chat/$threadId" params={{ threadId: t.id }} className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2">
                <MessagesSquare className="size-4 shrink-0 text-primary" /><span className="truncate">{t.title}</span>
              </Link>
              <button onClick={() => remove(t.id)} aria-label={`Delete ${t.title}`} className="p-2 text-muted-foreground hover:text-destructive"><Trash2 className="size-3.5" /></button>
            </li>
          ))}
        </ul>
      </aside>
      <ChatWindow key={threadId} threadId={threadId} />
    </section>
  );
}

function ChatWindow({ threadId }: { threadId: string }) {
  const initial = useMemo(() => getThread(threadId)?.messages ?? [], [threadId]);
  const [error, setError] = useState<string | null>(null);
  const { messages, sendMessage, status, stop } = useChat({
    id: threadId,
    messages: initial,
    transport: new DefaultChatTransport({ api: "/api/chat", body: { conversationId: threadId } }),
    onError: (e) => setError(e.message || "Something went wrong. Please try again."),
  });
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    if (status === "ready" || status === "error") {
      if (messages.length) saveMessages(threadId, messages);
    }
  }, [messages, status, threadId]);

  const send = (text: string) => {
    if (!text.trim() || busy) return;
    setError(null);
    saveMessages(threadId, [...messages, { id: crypto.randomUUID(), role: "user", parts: [{ type: "text", text }] }]);
    void sendMessage({ text });
  };

  return (
    <div className="flex h-[calc(100vh-10rem)] min-h-[480px] flex-col rounded-md border bg-card">
      <div className="flex items-center gap-3 border-b px-4 py-3">
        <img src={mark} alt="" className="h-8 w-auto" />
        <div><p className="font-display font-bold leading-tight">Ask JMEC</p><p className="text-xs text-muted-foreground">AI assistant · answers may need confirming with our team</p></div>
      </div>
      <Conversation className="flex-1">
        <ConversationContent>
          {messages.length === 0 ? (
            <ConversationEmptyState title="How can we help your brand?" description="Ask about our services, quotes or where to find us.">
              <div className="mt-2 flex flex-col items-center gap-3 text-center">
                <img src={mark} alt="" className="h-12 w-auto" />
                <p className="font-display text-lg font-bold">How can we help your brand?</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {starters.map((s) => <button key={s} onClick={() => send(s)} className="rounded-full border px-3 py-1.5 text-sm hover:border-primary hover:text-primary">{s}</button>)}
                </div>
              </div>
            </ConversationEmptyState>
          ) : (
            messages.map((m) => (
              <Message key={m.id} from={m.role}>
                <MessageContent className={m.role === "user" ? "!bg-primary !text-primary-foreground" : ""}>
                  {m.parts.map((p, i) => (p.type === "text" ? <MessageResponse key={i}>{p.text}</MessageResponse> : null))}
                </MessageContent>
              </Message>
            ))
          )}
          {status === "submitted" && <Shimmer className="text-sm">Thinking…</Shimmer>}
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>
      <div className="border-t p-3">
        <PromptInput onSubmit={(msg) => send(msg.text)}>
          <PromptInputBody>
            <PromptInputTextarea placeholder="Ask about branding, printing, signage…" autoFocus />
          </PromptInputBody>
          <PromptInputFooter className="justify-end">
            <PromptInputSubmit status={status} onStop={stop} disabled={false} />
          </PromptInputFooter>
        </PromptInput>
      </div>
    </div>
  );
}
