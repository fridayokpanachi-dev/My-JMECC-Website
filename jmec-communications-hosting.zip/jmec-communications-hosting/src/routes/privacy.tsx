import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/site/ui";
import { contact } from "@/lib/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/privacy")({
  staticData: { sitemap: true },
  head: () => seo("Privacy Policy — JMEC Communications", "How JMEC Communications handles information you share through enquiries.", "/privacy"),
  component: () => (
    <>
      <PageHero eyebrow="Legal" title="Privacy Policy" />
      <section className="mx-auto max-w-3xl space-y-4 px-5 py-16 text-muted-foreground">
        <p>When you send an enquiry, the details you provide (such as your name, email, phone number and project information) are used only to respond to your request and deliver our services.</p>
        <p>We do not sell your information. Enquiries are sent directly to our team by email or WhatsApp.</p>
        <p>To ask about or remove your information, email <a className="text-primary" href={`mailto:${contact.email}`}>{contact.email}</a>.</p>
      </section>
    </>
  ),
});
