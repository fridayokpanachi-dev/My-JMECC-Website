import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/site/ui";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/terms")({
  staticData: { sitemap: true },
  head: () => seo("Terms of Use — JMEC Communications", "Terms for using the JMEC Communications website.", "/terms"),
  component: () => (
    <>
      <PageHero eyebrow="Legal" title="Terms of Use" />
      <section className="mx-auto max-w-3xl space-y-4 px-5 py-16 text-muted-foreground">
        <p>Content and portfolio images on this website belong to JMEC Communications or their respective owners and may not be reused without permission.</p>
        <p>Information on this site is provided for general guidance. Quotes, timelines and specifications are confirmed in writing for each project.</p>
      </section>
    </>
  ),
});
