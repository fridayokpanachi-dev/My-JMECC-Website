import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { btn, PageHero } from "@/components/site/ui";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Wand2 } from "lucide-react";
import { MessageResponse } from "@/components/ai-elements/message";
import { summariseEnquiry } from "@/lib/ai.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Enquiries — JMEC Communications staff" },
      { name: "description", content: "Review quote requests and messages sent through the website." },
      { property: "og:title", content: "Enquiries — JMEC Communications staff" },
      { property: "og:description", content: "Review quote requests and messages sent through the website." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

function AiSummary({ id }: { id: string }) {
  const run = useServerFn(summariseEnquiry);
  const [busy, setBusy] = useState(false);
  const [text, setText] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  async function go() {
    setBusy(true); setErr(null);
    try { setText((await run({ data: { id } })).text); }
    catch (e) { setErr(e instanceof Error ? e.message : "Couldn't summarise right now."); }
    finally { setBusy(false); }
  }
  return (
    <div className="mt-3">
      {!text && <button onClick={go} disabled={busy} className="inline-flex items-center gap-1.5 rounded border border-primary px-2.5 py-1 text-xs font-medium text-primary disabled:opacity-50">
        {busy ? <Loader2 className="size-3.5 animate-spin" /> : <Wand2 className="size-3.5" />} {busy ? "Summarising…" : "Summarise & draft reply with AI"}
      </button>}
      {err && <p className="mt-1 text-xs text-destructive">{err}</p>}
      {text && <div className="mt-2 rounded-md border bg-secondary/40 p-4 text-sm"><MessageResponse>{text}</MessageResponse></div>}
    </div>
  );
}

const statuses = [["new", "New"], ["in_progress", "In progress"], ["done", "Done"]] as const;

function Admin() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-enquiries"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: u.user!.id, _role: "admin" });
      if (!isAdmin) return { isAdmin: false, rows: [] };
      const { data: rows, error } = await supabase.from("enquiries").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return { isAdmin: true, rows: rows ?? [] };
    },
  });

  async function setStatus(id: string, status: string) {
    await supabase.from("enquiries").update({ status }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["admin-enquiries"] });
  }
  async function openFile(path: string) {
    const { data: s } = await supabase.storage.from("enquiry-files").createSignedUrl(path, 300);
    if (s) window.open(s.signedUrl, "_blank", "noopener");
  }
  async function signOut() {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <>
      <PageHero eyebrow="Staff area" title="Enquiries"><button onClick={signOut} className={btn({ variant: "outline" })}>Sign out</button></PageHero>
      <section className="mx-auto max-w-6xl px-5 py-12">
        {isLoading && <p className="text-muted-foreground">Loading…</p>}
        {data && !data.isAdmin && <p className="text-muted-foreground">Your account doesn't have access to enquiries.</p>}
        {data?.isAdmin && data.rows.length === 0 && <p className="text-muted-foreground">No enquiries yet.</p>}
        <div className="grid gap-4">
          {data?.rows.map((r) => (
            <article key={r.id} className="rounded-md border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">{r.reference} · {new Date(r.created_at).toLocaleString()} · {r.kind === "quote" ? "Quote request" : "Message"}</p>
                  <h2 className="mt-1 text-lg font-bold">{r.name}{r.company && <span className="font-normal text-muted-foreground"> — {r.company}</span>}</h2>
                  <p className="text-sm"><a href={`mailto:${r.email}`} className="text-primary">{r.email}</a>{r.phone && <> · <a href={`tel:${r.phone}`} className="text-primary">{r.phone}</a></>}</p>
                </div>
                <select value={r.status} onChange={(e) => setStatus(r.id, e.target.value)} className="rounded-md border bg-card px-2 py-1.5 text-sm" aria-label="Status">
                  {statuses.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              <dl className="mt-3 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                {([["Service", r.service], ["Quantity", r.quantity], ["Specifications", r.specs], ["Delivery date", r.preferred_date], ["Budget", r.budget], ["Contact by", r.contact_method]] as const)
                  .filter(([, x]) => x).map(([k, x]) => <div key={k}><dt className="inline text-muted-foreground">{k}: </dt><dd className="inline">{x}</dd></div>)}
              </dl>
              <p className="mt-3 whitespace-pre-wrap text-sm">{r.message}</p>
              <AiSummary id={r.id} />
              {r.files.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {r.files.map((p) => <button key={p} onClick={() => openFile(p)} className="rounded border px-2 py-1 text-xs text-primary">{p.split("/").pop()?.replace(/^[0-9a-f-]{36}-/, "")}</button>)}
                </div>
              )}
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
