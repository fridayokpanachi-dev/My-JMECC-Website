import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { createThread, loadThreads } from "@/lib/chat-threads";

export const Route = createFileRoute("/chat/")({
  staticData: { sitemap: false },
  ssr: false,
  head: () => ({
    meta: [
      { title: "Ask JMEC — AI assistant | JMEC Communications" },
      { name: "description", content: "Ask our AI assistant about branding, printing, signage and how to get a quote from JMEC Communications." },
      { property: "og:title", content: "Ask JMEC — AI assistant" },
      { property: "og:description", content: "Instant answers about JMEC Communications services in Lagos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChatIndex,
});

function ChatIndex() {
  const navigate = useNavigate();
  const done = useRef(false);
  useEffect(() => {
    if (done.current) return;
    done.current = true;
    const t = loadThreads()[0] ?? createThread();
    navigate({ to: "/chat/$threadId", params: { threadId: t.id }, replace: true });
  }, [navigate]);
  return <p className="px-5 py-20 text-center text-muted-foreground">Opening the assistant…</p>;
}
