import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, type UIMessage } from "ai";
import { friendlyError, startCall } from "@/lib/ai/gateway.server";
import { withLovableAiGatewayRunIdHeader } from "@/lib/ai/run-id.server";
import { companyFacts, HONESTY_RULES } from "@/lib/ai/knowledge";

const INSTRUCTIONS = `You are the website assistant for JMEC Communications. Help visitors understand services, pick the right service, and get in touch.
${companyFacts()}
${HONESTY_RULES}
- When a visitor seems ready, suggest the "Request a Quote" page (/quote) or WhatsApp 08086479092.`;

export const Route = createFileRoute("/api/chat")({
  staticData: { sitemap: false },
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: { messages?: unknown };
        try { body = await request.json(); } catch { return new Response("Bad request", { status: 400 }); }
        const messages = Array.isArray(body.messages) ? (body.messages as UIMessage[]).slice(-30) : null;
        if (!messages?.length) return new Response("Bad request", { status: 400 });
        const { result, runIdFetch } = startCall({
          request,
          instructions: INSTRUCTIONS,
          messages: await convertToModelMessages(messages),
        });
        return withLovableAiGatewayRunIdHeader(
          result.toUIMessageStreamResponse({ originalMessages: messages, sendReasoning: false, onError: friendlyError }),
          runIdFetch,
        );
      },
    },
  },
});
