import { createFileRoute, Link } from "@tanstack/react-router";
import { btn, ClosingCta, PageHero } from "@/components/site/ui";
import { industries } from "@/lib/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/industries")({
  staticData: { sitemap: true },
  head: () => seo("Industries We Serve — JMEC Communications Lagos", "Branding and printing for corporates, SMEs, retail, events, schools, hospitality and personal brands across Nigeria.", "/industries"),
  component: Industries,
});

function Industries() {
  return (
    <>
      <PageHero eyebrow="Industries" title="Built for organizations of every size" intro="Whoever your audience is, we tailor the brand experience to reach them." />
      <section className="mx-auto max-w-6xl px-5 py-20">
        <div className="grid gap-px overflow-hidden rounded-md border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {industries.map((i, n) => (
            <div key={i.name} className="bg-card p-8">
              <span className="font-display text-sm text-primary">{String(n + 1).padStart(2, "0")}</span>
              <h2 className="mt-4 text-xl font-bold">{i.name}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{i.text}</p>
            </div>
          ))}
          <div className="flex flex-col justify-between bg-navy p-8 text-navy-foreground">
            <h2 className="text-xl font-bold">Don't see your sector?</h2>
            <Link to="/contact" className={btn({ variant: "light" }) + " mt-6 self-start"}>Talk to us</Link>
          </div>
        </div>
      </section>
      <ClosingCta />
    </>
  );
}
