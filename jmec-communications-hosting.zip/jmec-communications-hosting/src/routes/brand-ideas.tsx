import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Wand2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { MessageResponse } from "@/components/ai-elements/message";
import { btn, PageHero } from "@/components/site/ui";
import { brandIdeas } from "@/lib/ai.functions";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/brand-ideas")({
  staticData: { sitemap: true },
  head: () => seo("Free Brand Idea Generator — JMEC Communications", "Get instant slogan, colour and brand personality ideas for your business, powered by AI, from JMEC Communications in Lagos.", "/brand-ideas"),
  component: BrandIdeas,
});

const field = "mt-1.5 w-full rounded-md border bg-card px-3 py-2.5 text-sm";

function BrandIdeas() {
  const run = useServerFn(brandIdeas);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const v = (k: string) => String(f.get(k) ?? "").trim();
    if (v("business").length < 2) return setError("Please enter your business name.");
    setBusy(true); setError(null); setResult(null);
    try {
      const r = await run({ data: { business: v("business"), industry: v("industry"), about: v("about") } });
      setResult(r.text);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHero eyebrow="AI brand ideas" title="Spark ideas for your brand" intro="Tell us about your business and get slogan, colour and brand personality ideas in seconds. Free to try." />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-[1fr_1.4fr]">
        <form onSubmit={submit} className="grid h-fit gap-5 rounded-md border bg-card p-6">
          <label className="text-sm font-medium">Business name *<input name="business" required maxLength={120} className={field} /></label>
          <label className="text-sm font-medium">Industry<input name="industry" maxLength={120} placeholder="e.g. Restaurant, Microfinance, Fashion" className={field} /></label>
          <label className="text-sm font-medium">What makes you different?<textarea name="about" rows={4} maxLength={1500} className={field} /></label>
          <button disabled={busy} className={btn({ variant: "primary" })}>{busy ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}{busy ? "Creating ideas…" : "Generate ideas"}</button>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        </form>
        <div className="rounded-md border p-6">
          {result ? (
            <>
              <MessageResponse>{result}</MessageResponse>
              <p className="mt-6 text-xs text-muted-foreground">AI-generated suggestions — our designers will refine them with you.</p>
              <Link to="/quote" search={{ service: "Branding" }} className={btn({ variant: "primary" }) + " mt-4"}>Bring my brand to life</Link>
            </>
          ) : (
            <p className="text-muted-foreground">{busy ? "Our AI is brainstorming…" : "Your ideas will appear here."}</p>
          )}
        </div>
      </section>
    </>
  );
}
