import { createFileRoute, Link } from "@tanstack/react-router";
import { btn, ClosingCta, PageHero, SectionHead } from "@/components/site/ui";
import { criteria, images, values } from "@/lib/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/about")({
  staticData: { sitemap: true },
  head: () => seo("About JMEC Communications — Creative Agency in Lagos", "An independent, agile and people-driven creative agency in Lagos. Our philosophy, core values and design criteria.", "/about"),
  component: About,
});

function About() {
  return (
    <>
      <PageHero eyebrow="About us" title="Creativity takes courage." intro="JMEC Communications is an independent, agile and people-driven creative agency based in the heart of Lagos." />
      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-20 md:grid-cols-2">
        <div className="space-y-4 text-muted-foreground">
          <SectionHead eyebrow="Who we are" title="Design that shapes perception" />
          <p>Our team creates visually engaging and thought-provoking designs. We provide capabilities in design, content development and implementation that shape perception and connect brands with customers.</p>
          <p>Using our creativity and strategic resources, we offer custom-made solutions that consider the uniqueness of each brand and its objectives. Before recommending solutions, we carefully study the client, the product and the market.</p>
        </div>
        <div className="space-y-4 text-muted-foreground">
          <SectionHead eyebrow="Our philosophy" title="Clinical study, tailored solutions" />
          <p>Our creative philosophy leans towards the careful study of each client's particular challenges — past, present and future — the realities of their business environment, and tailor-made solutions that honour stated core values and connect powerfully with people.</p>
          <p>We combine insight about our clients' market and their brand attributes to create solutions that build trust.</p>
        </div>
      </section>
      <section className="bg-secondary">
        <div className="mx-auto max-w-6xl px-5 py-20">
          <SectionHead eyebrow="Our design criteria" title="Five tests every brand expression must pass" />
          <ol className="mt-10 grid gap-6 md:grid-cols-5">
            {criteria.map((c, i) => (
              <li key={c.name} className="notch rounded-md bg-card p-6 pt-14">
                <span className="font-display text-sm text-primary">0{i + 1}</span>
                <h3 className="mt-2 text-lg font-bold">{c.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{c.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-20">
        <SectionHead eyebrow="Core values" title="Promptness. Relationship. Innovation. Diligence. Excellence." />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {values.map((v) => <div key={v.name} className="border-t-2 border-primary pt-4"><h3 className="font-bold">{v.name}</h3><p className="mt-2 text-sm text-muted-foreground">{v.text}</p></div>)}
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 pb-20">
        <SectionHead eyebrow="Portfolio highlights" title="A glimpse of our work" />
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[images.interiors, images.vehicle, images.pos].map((s) => <img key={s} src={s} alt="JMEC portfolio highlight" loading="lazy" className="aspect-[4/3] w-full rounded-md object-cover" />)}
        </div>
        <Link to="/portfolio" className={btn({ variant: "outline" }) + " mt-8"}>See all work</Link>
      </section>
      <ClosingCta />
    </>
  );
}
