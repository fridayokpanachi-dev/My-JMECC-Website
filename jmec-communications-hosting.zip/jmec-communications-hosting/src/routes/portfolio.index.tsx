import { createFileRoute } from "@tanstack/react-router";
import { PortfolioGrid } from "@/components/site/PortfolioGrid";
import { ClosingCta, PageHero } from "@/components/site/ui";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/portfolio/")({
  staticData: { sitemap: true },
  head: () => seo("Our Work — Branding, Signage & Print Portfolio | JMEC", "Browse JMEC Communications projects: brand identity, interiors, point-of-sale, vehicle branding, websites and more.", "/portfolio"),
  component: Portfolio,
});

function Portfolio() {
  return (
    <>
      <PageHero eyebrow="Portfolio" title="Our work" intro="Search and filter selected projects across design, branding, environments, displays and digital." />
      <section className="mx-auto max-w-6xl px-5 py-16"><PortfolioGrid search /></section>
      <ClosingCta />
    </>
  );
}
