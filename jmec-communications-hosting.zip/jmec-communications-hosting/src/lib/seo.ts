export const SITE_URL = "https://jmec-story-and-signal.lovable.app";

export const seo = (title: string, description: string, path = "/") => ({
  meta: [
    { title },
    { name: "description", content: description },
    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { property: "og:url", content: `${SITE_URL}${path}` },
    { name: "twitter:card", content: "summary_large_image" },
  ],
  links: [{ rel: "canonical", href: `${SITE_URL}${path}` }],
});
