import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateFinal } from "@/lib/ai/gateway.server";
import { companyFacts, HONESTY_RULES } from "@/lib/ai/knowledge";

const quoteInput = z.object({ service: z.string().max(80), draft: z.string().min(3).max(3000) });

/** Rewrites a visitor's rough project description into a clear brief. */
export const improveQuote = createServerFn({ method: "POST" })
  .validator((d: unknown) => quoteInput.parse(d))
  .handler(async ({ data }) => {
    const text = await generateFinal(
      `You help visitors of JMEC Communications (a Lagos branding, printing and signage agency) write clear quote requests.
Rewrite the visitor's notes into a clear project description in first person, as plain text (no markdown, no headings), under 150 words.
Keep every fact they gave. Do not add facts, quantities, sizes, dates or budgets they did not give.
After the description, add a line "Details that would help:" followed by 2-4 short questions about missing info (e.g. quantity, size, material, delivery date, artwork). Skip any already answered.`,
      `Service: ${data.service || "not chosen"}\nVisitor notes:\n${data.draft}`,
    );
    return { text: text.trim() };
  });

const ideasInput = z.object({
  business: z.string().min(2).max(120),
  industry: z.string().max(120),
  about: z.string().max(1500),
});

/** Brand idea generator for visitors. */
export const brandIdeas = createServerFn({ method: "POST" })
  .validator((d: unknown) => ideasInput.parse(d))
  .handler(async ({ data }) => {
    const text = await generateFinal(
      `You are a creative brand strategist at JMEC Communications, Lagos ("...we brand beyond comparison").
Give a visitor quick, original branding ideas in markdown with these sections:
## Slogan ideas (5 short options)
## Brand personality (3 words, one line each)
## Colour direction (2 palettes, describe colours in words with why)
## Where to show your brand (4 practical items, e.g. signage, vehicle branding, packaging, social media)
End with one sentence inviting them to request a quote from JMEC to bring it to life. No prices or timelines.`,
      `Business name: ${data.business}\nIndustry: ${data.industry || "not given"}\nAbout: ${data.about || "not given"}`,
      "medium",
    );
    return { text };
  });

/** Staff only: summarise an enquiry and draft a reply. */
export const summariseEnquiry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Not allowed");
    const { data: e, error } = await context.supabase.from("enquiries").select("*").eq("id", data.id).single();
    if (error || !e) throw new Error("Enquiry not found");
    const details = Object.entries({
      Type: e.kind, Name: e.name, Company: e.company, Service: e.service, Quantity: e.quantity, Specs: e.specs,
      "Delivery date": e.preferred_date, Budget: e.budget, "Contact by": e.contact_method, Files: e.files.length, Message: e.message,
    }).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join("\n");
    const text = await generateFinal(
      `You help JMEC Communications staff handle website enquiries.
${companyFacts()}
${HONESTY_RULES}
Reply in markdown with:
**Summary** — 2-3 bullet points on what the client wants.
**Missing details** — bullets of what to ask (skip if none).
**Suggested reply** — a short, friendly reply to the client signed "JMEC Communications". Leave prices and timelines as [to confirm].`,
      details,
    );
    return { text };
  });
