import { createOpenAI } from "@ai-sdk/openai";
import { APICallError, streamText, type ModelMessage } from "ai";
import { createLovableAiGatewayRunIdFetch, getLovableAiGatewayRunId } from "./run-id.server.ts";

const BASE_URL = "https://ai.gateway.lovable.dev/v1";
export const MODEL = "openai/gpt-6-astra";

export function startCall(opts: {
  request?: Request;
  instructions: string;
  messages: ModelMessage[];
  effort?: "low" | "medium";
}) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured yet.");
  const runIdFetch = createLovableAiGatewayRunIdFetch(opts.request ? getLovableAiGatewayRunId(opts.request) : undefined);
  const provider = createOpenAI({
    baseURL: BASE_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });
  const result = streamText({
    model: provider.responses(MODEL),
    instructions: opts.instructions,
    messages: opts.messages,
    maxRetries: 1,
    ...(opts.request ? { abortSignal: opts.request.signal } : {}),
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: opts.effort ?? "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  return { result, runIdFetch };
}

/** Friendly message for a gateway failure. */
export function friendlyError(error: unknown): string {
  const status = APICallError.isInstance(error) ? error.statusCode : undefined;
  if (status === 429) return "The assistant is busy right now. Please try again in a minute.";
  if (status === 402) return "The AI features have used up their credits. Please contact the site owner.";
  if (status === 403) return "The AI service declined this request.";
  console.error("AI error", error);
  return "Sorry, something went wrong. Please try again.";
}

/** Runs a one-shot request and returns the final text. */
export async function generateFinal(instructions: string, prompt: string, effort: "low" | "medium" = "low") {
  const { result } = startCall({ instructions, messages: [{ role: "user", content: prompt }], effort });
  let failure: unknown;
  try {
    const text = await result.text;
    if (!text.trim()) throw new Error("empty");
    return text;
  } catch (e) {
    failure = e;
  }
  throw new Error(friendlyError(failure));
}
