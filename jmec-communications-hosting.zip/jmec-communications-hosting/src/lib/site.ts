import collage from "@/assets/collage.jpg.asset.json";
import design from "@/assets/design.jpg.asset.json";
import branding from "@/assets/branding.jpg.asset.json";
import interiors from "@/assets/interiors.jpg.asset.json";
import pos from "@/assets/pos.jpg.asset.json";
import vehicle from "@/assets/vehicle.jpg.asset.json";
import social from "@/assets/social.jpg.asset.json";
import web from "@/assets/web.jpg.asset.json";
import responsive from "@/assets/responsive.jpg.asset.json";
import imperialBanner from "@/assets/imperial-banner.png.asset.json";
import imperialWindows from "@/assets/imperial-windows.jpg.asset.json";
import moneyfield from "@/assets/moneyfield-sign.jpg.asset.json";
import capitalfield from "@/assets/capitalfield-sign.jpg.asset.json";
import prestige from "@/assets/prestige-flask.jpg.asset.json";
import bridgeHotel from "@/assets/bridge-hotel.jpg.asset.json";
import trophy from "@/assets/trophy-display.jpg.asset.json";
import avaCapital from "@/assets/ava-capital.jpg.asset.json";
import jadeite from "@/assets/jadeite-pylon.jpg.asset.json";
import celebrationBag from "@/assets/celebration-bag.jpg.asset.json";
import prestigeCertificate from "@/assets/prestige-motor-certificate.jpeg.asset.json";
import prestigePolicy from "@/assets/prestige-policy-documents.jpeg.asset.json";
import prestigeStationery from "@/assets/prestige-stationery.jpeg.asset.json";
import imperialFascia from "@/assets/imperial-fascia.jpeg.asset.json";
import moneyfieldDisplays from "@/assets/moneyfield-counter-displays.jpeg.asset.json";
import moneyfieldPylon from "@/assets/moneyfield-pylon.jpeg.asset.json";
import moneyfieldBuilding from "@/assets/moneyfield-building-branding.jpeg.asset.json";
import prestigeBagFront from "@/assets/prestige-bag-front.png.asset.json";
import prestigeBagReverse from "@/assets/prestige-bag-reverse.png.asset.json";
import clientPrestige from "@/assets/client-prestige.png.asset.json";
import clientCapitalfield from "@/assets/client-capitalfield.png.asset.json";
import clientMoneyfield from "@/assets/client-moneyfield.png.asset.json";
import clientImperial from "@/assets/client-imperial.png.asset.json";
import clientTofa from "@/assets/client-tofa-dark.png.asset.json";
import clientCompass from "@/assets/client-compass-dark.png.asset.json";
import clientSchneider from "@/assets/client-schneider.png.asset.json";

export const images = {
  collage: collage.url, design: design.url, branding: branding.url, interiors: interiors.url,
  pos: pos.url, vehicle: vehicle.url, social: social.url, web: web.url, responsive: responsive.url,
};

export const contact = {
  name: "JMEC Communications",
  address: "13 Aiyetoro Street, Aguda Surulere, Lagos, Nigeria",
  phones: ["07030332468", "08086479092"],
  email: "info@jmeccomms.com.ng",
  website: "www.jmeccomms.com.ng",
  whatsapp: "2348086479092",
  tagline: "...we brand beyond comparison",
};

/** To add a logo: upload the file as a CDN asset pointer and set `logo` below. `dark` puts white logos on a navy card. */
export type Client = { name: string; logo?: string; dark?: boolean };

export const clients: Client[] = [
  { name: "Prestige Assurance PLC", logo: clientPrestige.url },
  { name: "Capitalfield Investment Group PLC", logo: clientCapitalfield.url },
  { name: "Moneyfield Microfinance Bank LTD", logo: clientMoneyfield.url },
  { name: "Imperial Power & Energy Solutions Nig. LTD", logo: clientImperial.url },
  { name: "Compass Nigeria LTD", logo: clientCompass.url },
  { name: "TOFA Nigeria", logo: clientTofa.url },
  { name: "Sankin Industries LTD" },
  { name: "Schneider Electric", logo: clientSchneider.url },
];

export const telHref = (p: string) => `tel:+234${p.replace(/^0/, "")}`;

export const whatsappHref = (text: string) =>
  `https://wa.me/${contact.whatsapp}?text=${encodeURIComponent(text)}`;

/** Opens WhatsApp directly: the app on phones, WhatsApp Web on computers (avoids the api.whatsapp.com redirect that some browsers/frames block). */
export function openWhatsApp(e: { preventDefault: () => void }, text: string) {
  if (typeof window === "undefined") return;
  e.preventDefault();
  const q = `phone=${contact.whatsapp}&text=${encodeURIComponent(text)}`;
  const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  if (mobile) {
    window.location.href = `whatsapp://send?${q}`;
  } else {
    const w = window.open(`https://web.whatsapp.com/send?${q}`, "_blank", "noopener,noreferrer");
    if (!w) window.location.href = `https://web.whatsapp.com/send?${q}`;
  }
}

export const homeServices = [
  { title: "Brand Identity Development", text: "Corporate and personal identities built to be distinctive, relevant and memorable.", group: "branding" },
  { title: "Brand Activation & Communications", text: "Bringing brands to life where audiences meet them.", group: "digital" },
  { title: "Digital Branding, Websites & Social", text: "Websites, online engagement and social media that extend your brand.", group: "digital" },
  { title: "Environmental & Office Branding", text: "Internal and external look and feel that expresses your brand in space.", group: "signage" },
  { title: "Event Branding, Planning & Management", text: "Branded experiences, planned and managed end to end.", group: "events" },
  { title: "Point-of-Sale Display Systems", text: "Displays that win the first impression at the moment of purchase.", group: "signage" },
  { title: "Branded Display Solutions", text: "Display systems that carry your message with clarity.", group: "signage" },
  { title: "Commercial & Below-the-Line Printing", text: "Marketing materials, stationery and publications, printed professionally.", group: "printing" },
  { title: "Public Relations & Media Assistance", text: "Support for PR activities and media engagement.", group: "digital" },
  { title: "Outdoor Advertising & Branding", text: "Outdoor brand expressions designed to be seen and remembered.", group: "signage" },
];

export const serviceGroups = [
  { id: "branding", title: "Branding and Creative Design", image: images.branding, intro: "Identity and design work grounded in a careful study of the client, the product and the market.",
    items: ["Corporate and personal brand identity", "Brand refresh and positioning", "Brand strategy and architecture", "Graphic design and advertising layouts", "Packaging and publication design"] },
  { id: "printing", title: "Printing and Production", image: images.design, intro: "Print materials that carry your brand consistently, from stationery to publications.",
    items: ["Below-the-line marketing materials", "Corporate stationery and business documents", "Brochures, flyers and promotional materials", "Posters, reports and publications", "Other custom printing projects"] },
  { id: "signage", title: "Signage and Environmental Branding", image: images.interiors, intro: "Ambience is one of the key elements that differentiate brands. We infuse environments with your brand's essence.",
    items: ["Indoor and outdoor signage", "Office and corporate environment branding", "Retail branding and point-of-sale displays", "Branded display systems", "Vehicle branding"] },
  { id: "digital", title: "Digital and Communications", image: images.web, intro: "Practical, responsive digital solutions and communications that connect brands with people.",
    items: ["Website design", "Responsive UI/UX design", "Digital branding", "Social media content and engagement", "Brand activation and communications", "Public relations and media assistance"] },
  { id: "events", title: "Events and Promotions", image: images.pos, intro: "Branded events and promotions planned with the same strategic care as every other brand expression.",
    items: ["Event branding", "Event planning and management", "Promotional campaigns", "Exhibition and display branding"] },
];

export const quoteServices = ["Branding", "Printing", "Signage", "Vehicle branding", "Digital design", "Event branding", "Packaging", "Other"];

export const values = [
  { name: "Promptness", text: "We respect timelines and respond quickly, because brands move at the speed of business." },
  { name: "Relationship", text: "Our clients are our pride. We build partnerships, not transactions." },
  { name: "Innovation", text: "We look for fresh, imaginative ways for every brand to express itself." },
  { name: "Diligence", text: "We study each brief carefully and attend to every detail of execution." },
  { name: "Excellence", text: "We hold every deliverable, big or small, to a high standard." },
];

export const criteria = [
  { name: "Distinctiveness", text: "Helping brands stand out from competing brands." },
  { name: "Relevance", text: "Ensuring brand expressions support clearly defined objectives." },
  { name: "Memorability", text: "Making brands easier for their audiences to recall when it matters." },
  { name: "Extendability", text: "Brand expressions that work across media, cultural boundaries and message types." },
  { name: "Depth", text: "Communicating with different audiences without losing the brand's essence." },
];

export const industries = [
  { name: "Corporate organizations", text: "Consistent identity, environments and communications across the organization." },
  { name: "Small and medium-sized businesses", text: "Professional branding that helps growing businesses compete." },
  { name: "Retail and commercial businesses", text: "Signage, point-of-sale and packaging that win attention in store." },
  { name: "Event organizers", text: "Event branding, displays and printed materials delivered together." },
  { name: "Educational institutions", text: "Identity, signage and publications for schools and institutions." },
  { name: "Hospitality businesses", text: "Interiors, menus and signage that shape guest experience." },
  { name: "Entrepreneurs and personal brands", text: "Personal identities and digital presence built to be remembered." },
];

export const categories = [
  "Graphic Design", "Branding and Brand Identity", "Environmental Branding and Interiors", "Point-of-Sale Displays",
  "Vehicle Branding", "Printing and Publications", "Packaging Design", "Digital Branding and Websites", "Social Media", "Event Branding",
] as const;

export type Project = {
  slug: string; title: string; category: (typeof categories)[number]; image: string;
  description: string; services: string[]; client?: string; placeholder?: boolean; fit?: "contain";
};

export const projects: Project[] = [
  { slug: "prestige-motor-insurance-certificate", title: "Prestige motor insurance certificate", category: "Printing and Publications", image: prestigeCertificate.url,
    description: "Printed motor insurance certificate covers for Prestige Assurance Plc, featuring its yellow and blue branding and insurance product information.", services: ["Document design", "Commercial printing"] },
  { slug: "prestige-policy-documents", title: "Prestige policy documents", category: "Printing and Publications", image: prestigePolicy.url,
    description: "Branded policy document covers for Prestige Assurance Plc in its yellow and blue corporate colours.", services: ["Publication design", "Printing"] },
  { slug: "prestige-corporate-stationery", title: "Prestige corporate stationery", category: "Branding and Brand Identity", image: prestigeStationery.url,
    description: "Corporate stationery for Prestige Assurance Plc, with a prominent logo watermark and matching branded footer.", services: ["Stationery design", "Brand application", "Printing"] },
  { slug: "imperial-power-fascia-signage", title: "Imperial Power fascia signage", category: "Environmental Branding and Interiors", image: imperialFascia.url,
    description: "Exterior fascia signage presenting Imperial Power & Energy Solutions Nig. Ltd's name and power equipment services.", services: ["Outdoor signage", "Fascia branding"] },
  { slug: "moneyfield-counter-displays", title: "Moneyfield counter displays", category: "Point-of-Sale Displays", image: moneyfieldDisplays.url,
    description: "Countertop display panels for Moneyfield Microfinance Bank Limited, promoting mobile banking and account opening.", services: ["POS display systems", "Promotional graphics", "Printing"] },
  { slug: "moneyfield-pylon-sign", title: "Moneyfield pylon sign", category: "Environmental Branding and Interiors", image: moneyfieldPylon.url,
    description: "A roadside pylon sign for Moneyfield Microfinance Bank Limited with dimensional lettering, banking service listings and a QR code panel.", services: ["Pylon signage", "Outdoor branding"] },
  { slug: "moneyfield-building-branding", title: "Moneyfield building branding", category: "Environmental Branding and Interiors", image: moneyfieldBuilding.url,
    description: "Exterior branding at Capitalfield House, featuring Moneyfield Microfinance Bank Limited signage and green building panels.", services: ["Building branding", "Exterior signage"] },
  { slug: "graphic-design-selection", title: "Graphic design selection", category: "Graphic Design", image: images.design,
    description: "Whether it is graphics, ads layout or packaging design, our works drive people to action. A selection of print and advertising layouts from our corporate profile.", services: ["Graphic design", "Advertising layouts"] },
  { slug: "brand-identity-stationery", title: "Brand identity and stationery", category: "Branding and Brand Identity", image: images.branding,
    description: "As they say, fine dress helps to impress. We consider every element in the formation of a brand's image, from mark exploration to business cards.", services: ["Brand identity", "Stationery design", "Printing"] },
  { slug: "corporate-interior-branding", title: "Corporate interior branding", category: "Environmental Branding and Interiors", image: images.interiors,
    description: "We work on our clients' environments to infuse the vibes and essence of their brand while liberating the environment to become a nest of internal culture.", services: ["Environmental branding", "Wall graphics", "Signage"] },
  { slug: "point-of-sale-displays", title: "Point-of-sale displays", category: "Point-of-Sale Displays", image: images.pos,
    description: "First-impression dynamics play out every time a customer interacts with a brand at the point of sale. These display units were designed to make that contact count.", services: ["POS display systems", "Branded display solutions"] },
  { slug: "fleet-vehicle-branding", title: "Fleet vehicle branding", category: "Vehicle Branding", image: images.vehicle,
    description: "In keeping up with clients' need for visibility, we integrate the messages and images of their brand on the surface of their vehicles.", services: ["Vehicle branding", "Large-format printing"] },
  { slug: "social-media-engagement", title: "Social media engagement", category: "Social Media", image: images.social,
    description: "We help our clients listen to what is trending in their areas of interest and collect data that can be redeployed to strengthen their interaction with the online community.", services: ["Social media management", "Content"] },
  { slug: "event-website", title: "Event website", category: "Digital Branding and Websites", image: images.web, client: "christianleadershipng.org",
    description: "An event website built for christianleadershipng.org, presenting the event's message and programme online.", services: ["Website design", "Digital branding"] },
  { slug: "responsive-interfaces", title: "Responsive interfaces", category: "Digital Branding and Websites", image: images.responsive,
    description: "Depending on the task, we think a few steps beyond the obvious needs of clients. The result: solutions that are comfortable, practical and responsive on any device.", services: ["Responsive UI/UX design", "Web design"] },
  { slug: "brand-work-collage", title: "Selected brand work", category: "Printing and Publications", image: images.collage,
    description: "A collage of identity, display and print work featured on the opening page of our corporate profile.", services: ["Brand identity", "Displays", "Printing"] },
  { slug: "bridge-hotel-lobby-signage", title: "The Bridge Hotel lobby signage", category: "Environmental Branding and Interiors", image: bridgeHotel.url,
    description: "Illuminated lobby lettering and feature wall branding for The Bridge Hotel, Ibadan.", services: ["Environmental branding", "Illuminated signage"] },
  { slug: "ava-capital-reception-wall", title: "AVA Capital reception wall", category: "Environmental Branding and Interiors", image: avaCapital.url,
    description: "A branded reception wall for AVA Capital Plc, with dimensional lettering, a gold emblem and service listing.", services: ["Office branding", "Dimensional signage"] },
  { slug: "moneyfield-fascia-sign", title: "Moneyfield fascia sign", category: "Environmental Branding and Interiors", image: moneyfield.url,
    description: "Exterior fascia signage for Moneyfield Microfinance Bank Limited.", services: ["Outdoor signage"] },
  { slug: "capitalfield-house-sign", title: "Capitalfield House sign", category: "Environmental Branding and Interiors", image: capitalfield.url,
    description: "Building identity sign for Capitalfield House.", services: ["Outdoor signage", "Building branding"] },
  { slug: "jadeite-salon-pylon", title: "Jadeite Unisex Salon pylon sign", category: "Environmental Branding and Interiors", image: jadeite.url,
    description: "A roadside pylon sign with logo head and service panels for Jadeite Unisex Salon.", services: ["Outdoor signage", "Pylon sign"] },
  { slug: "trophy-lager-display", title: "Trophy lager light display", category: "Point-of-Sale Displays", image: trophy.url,
    description: "A shaped, illuminated bottle display for Trophy Premium Quality Lager.", services: ["POS display systems", "Illuminated displays"] },
  { slug: "imperial-power-window-graphics", title: "Imperial Power window graphics", category: "Environmental Branding and Interiors", image: imperialWindows.url,
    description: "Office window graphics presenting Imperial Power & Energy Solutions' services.", services: ["Window graphics", "Office branding"] },
  { slug: "imperial-power-banner", title: "Imperial Power banner design", category: "Graphic Design", image: imperialBanner.url,
    description: "Banner design for Imperial Power & Energy Solutions Nig. Ltd: installation, preventive maintenance and repairs of power equipment.", services: ["Graphic design", "Large-format printing"] },
  { slug: "prestige-branded-flask", title: "Prestige Assurance branded flask", category: "Branding and Brand Identity", image: prestige.url,
    description: "A branded flask carrying the Prestige Assurance Plc logo.", services: ["Branded merchandise"] },
  { slug: "celebration-gift-bag", title: "Celebration of life gift bag", category: "Packaging Design", image: celebrationBag.url,
    description: "A custom printed gift bag designed for an 85th celebration of life.", services: ["Packaging design", "Printing"] },
  { slug: "prestige-assurance-carry-bag", title: "Prestige Assurance printed carry bag", category: "Packaging Design", image: prestigeBagFront.url, fit: "contain",
    description: "A custom printed carry bag for Prestige Assurance Plc, with its globe logo, slogan and insurance services printed across blue, white and yellow panels.", services: ["Packaging design", "Custom printed bags", "Printing"] },
  { slug: "prestige-assurance-carry-bag-branding", title: "Prestige Assurance carry bag branding panel", category: "Branding and Brand Identity", image: prestigeBagReverse.url, fit: "contain",
    description: "The reverse panel of a printed carry bag for Prestige Assurance Plc, carrying a repeating logo watermark, the company's contact details and the line \"Your Professional Risk Partner\".", services: ["Brand application", "Print design"] },
  { slug: "event-branding-placeholder", title: "Event branding project (coming soon)", category: "Event Branding", image: images.pos, placeholder: true,
    description: "Placeholder — project details and images will be added by the JMEC team.", services: ["Event branding"] },
];
