import type { UIMessage } from "ai";

export type Thread = { id: string; title: string; updatedAt: number; messages: UIMessage[] };
const KEY = "jmec-chat-threads";

export function loadThreads(): Thread[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    return Array.isArray(raw) ? (raw as Thread[]).sort((a, b) => b.updatedAt - a.updatedAt) : [];
  } catch {
    return [];
  }
}

function save(threads: Thread[]) {
  localStorage.setItem(KEY, JSON.stringify(threads));
  window.dispatchEvent(new Event("jmec-threads"));
}

export function createThread(): Thread {
  const t: Thread = { id: crypto.randomUUID().slice(0, 8), title: "New conversation", updatedAt: Date.now(), messages: [] };
  save([t, ...loadThreads()]);
  return t;
}

export function getThread(id: string) {
  return loadThreads().find((t) => t.id === id);
}

export function saveMessages(id: string, messages: UIMessage[]) {
  const threads = loadThreads();
  const firstUser = messages.find((m) => m.role === "user");
  const firstText = firstUser?.parts.find((p) => p.type === "text");
  const title = firstText && "text" in firstText ? firstText.text.slice(0, 48) : "New conversation";
  const existing = threads.find((t) => t.id === id);
  const next = existing
    ? threads.map((t) => (t.id === id ? { ...t, messages, title, updatedAt: Date.now() } : t))
    : [{ id, title, messages, updatedAt: Date.now() }, ...threads];
  save(next);
}

export function deleteThread(id: string) {
  save(loadThreads().filter((t) => t.id !== id));
}
